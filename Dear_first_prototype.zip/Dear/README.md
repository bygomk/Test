# Dear — first prototype

A single-file mobile web prototype inspired by the user's visual references.

## Run
Open `index.html` in a modern browser. On iPhone, upload the folder to a static host (for example GitHub Pages or Netlify), then open the HTTPS link in Safari.

## Current prototype
- Aged paper-like writing surface and warm spotlight
- Typewriter-style monospaced text
- Native iOS keyboard when focused in Safari
- Character counter (3,000)
- Simple moving carriage/light response
- Share action

## Known limitations in this first pass
- Carriage movement is an approximation, not true glyph-level tracking.
- No mechanical sound yet.
- No conversation sync or accounts yet.
- iOS Safari controls keyboard appearance and viewport behavior.
